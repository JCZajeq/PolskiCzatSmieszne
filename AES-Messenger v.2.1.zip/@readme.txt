=================Autor=================
Autor: NotKr0nos
Data wydania: 2021-02-14
Wersja 2.1
=================Zastosowanie=================
Program służy do szyfrowania/deszyfrowania wiadomości

=================Who cares?=================
Moduł szyfrujący korzysta z algorytmu AES(advanced encryption standard) z 256 bitowym kluczem

=================Jak używać=================
instrukcja.txt